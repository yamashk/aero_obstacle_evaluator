export default {
  selectMapWidget: "Select Map Widget",
  layerNameInput: "Enter layer name",
  layerDescriptionFieldInput: "Enter layer's description field name",
};
