import { React, FormattedMessage } from "jimu-core";
import { AllWidgetSettingProps } from "jimu-for-builder";
import defaultMessages from "./translations/default";
import {
  JimuMapViewSelector,
  SettingSection,
} from "jimu-ui/advanced/setting-components";
import { NormalModuleReplacementPlugin } from "webpack";

interface State {
  layerName: string;
  layerDescriptionField: string;
}

export default class Setting extends React.Component<
  AllWidgetSettingProps<{}>,
  any
> {
  constructor(props) {
    super(props);

    this.state = {
      layerName: this.props.config.layerName,
      layerDescriptionField: this.props.config.layerDescriptionField,
    };
  }

  onMapWidgetSelected = (useMapWidgetIds: string[]) => {
    this.props.onSettingChange({
      id: this.props.id,
      useMapWidgetIds: useMapWidgetIds,
    });
  };

  onLayerNameChanged = (event: any) => {
    let config = this.props.config;
    config.layerName = event.target.value;
    this.setState({ layerName: config.layerName });
    this.props.onSettingChange({
      id: this.props.id,
      config,
    });
  };

  onLayerDescriptionFieldChanged = (event: any) => {
    let config = this.props.config;
    config.layerDescriptionField = event.target.value;
    this.setState({ layerDescriptionField: config.layerDescriptionField });
    this.props.onSettingChange({
      id: this.props.id,
      config,
    });
  };

  render() {
    return (
      <div className="widget-setting-js-api-widget">
        <SettingSection
          className="map-selector-section"
          title={this.props.intl.formatMessage({
            id: "selectMapWidget",
            defaultMessage: defaultMessages.selectMapWidget,
          })}
        >
          <JimuMapViewSelector
            onSelect={this.onMapWidgetSelected}
            useMapWidgetIds={this.props.useMapWidgetIds}
          />
        </SettingSection>
        <SettingSection
          className="layer-name-section"
          title={this.props.intl.formatMessage({
            id: "layerNameInput",
            defaultMessage: defaultMessages.layerNameInput,
          })}
        >
          <input
            type="text"
            name="layerNameInput"
            style={{ width: "100%" }}
            value={this.state.layerName}
            onChange={this.onLayerNameChanged}
          />
        </SettingSection>
        <SettingSection
          className="layer-description-field-section"
          title={this.props.intl.formatMessage({
            id: "layerDescriptionFieldInput",
            defaultMessage: defaultMessages.layerDescriptionFieldInput,
          })}
        >
          <input
            type="text"
            name="layerDescriptionFieldInput"
            style={{ width: "100%" }}
            value={this.state.layerDescriptionField}
            onChange={this.onLayerDescriptionFieldChanged}
          />
        </SettingSection>
      </div>
    );
  }
}
