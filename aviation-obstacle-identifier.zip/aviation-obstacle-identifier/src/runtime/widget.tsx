/** @jsx jsx */
import { React, AllWidgetProps, css, jsx, AppConfig } from "jimu-core";
import { TextInput, Button, Icon } from "jimu-ui";
import {
  loadArcGISJSAPIModules,
  JimuMapViewComponent,
  JimuMapView,
  MapViewManager,
} from "jimu-arcgis";
import { getStyle } from "./style";
import defaultMessages from "./translations/default";
import { jimuMapViewAdded } from "jimu-core/lib/app-actions";
import HighlightHelper from "dist/widgets/arcgis/fly-controller/src/runtime/components/helpers/highlight-helper";
import { themeQuickStylerStyles } from "jimu-ui/advanced/lib/theme-components/styles/theme-quickstyler";
import { navMenuStyles } from "jimu-ui/lib/styles/components/nav-menu";

interface State {
  errorMessage: string;
  surfaceLayer: any;
  jimuMapView: JimuMapView;
  highlight: any;
  disableMapNav: boolean;
  obstacleTop: any;
  obstacleSurface: any;
  obstacleGround: any;
  obstacleLine: any;
  originalHitHeight: number;
  surfaceDescription: string;
}

export default class Widget extends React.PureComponent<
  AllWidgetProps<{}>,
  State
> {
  private myRef = React.createRef<HTMLDivElement>();
  private resetButtonRef = React.createRef<HTMLButtonElement>();
  private submitButtonRef = React.createRef<HTMLButtonElement>();

  private obstacleXRef = React.createRef<HTMLInputElement>();
  private obstacleYRef = React.createRef<HTMLInputElement>();
  private obstacleZRef = React.createRef<HTMLInputElement>();

  // symbol for points on objects
  private objectPointSymbol = {
    type: "point-3d",
    symbolLayers: [
      {
        type: "icon", // autocasts as new IconSymbol3DLayer()
        size: 12, // points
        resource: { primitive: "circle" },
        material: { color: "dodgerblue" },
        outline: {
          color: "deepskyblue",
        },
      },
    ],
  };

  // symbol for first object hit point
  private firstObjectPointSymbol = {
    type: "point-3d",
    symbolLayers: [
      {
        type: "icon", // autocasts as new IconSymbol3DLayer()
        size: 12, // points
        resource: { primitive: "circle" },
        material: { color: "darkblue" },
        outline: {
          color: "deepskyblue",
        },
      },
    ],
  };

  // symbol for the ground point
  private groundPointSymbol = {
    type: "point-3d",
    symbolLayers: [
      {
        type: "icon", // autocasts as new IconSymbol3DLayer()
        size: 12, // points
        resource: { primitive: "circle" },
        material: { color: "darkgreen" },
        outline: {
          color: "limegreen",
        },
      },
    ],
  };

  // line symbol which connects the points
  private lineSymbol = {
    type: "line-3d", // autocasts as new LineSymbol3D()
    symbolLayers: [
      {
        type: "line", // autocasts as new LineSymbol3DLayer()
        material: {
          color: "dodgerblue",
        },
        size: 4,
      },
    ],
  };

  constructor(props) {
    super(props);

    this.state = {
      errorMessage: null,
      surfaceLayer: null,
      jimuMapView: null,
      highlight: null,
      disableMapNav: false,
      obstacleTop: null,
      obstacleSurface: null,
      obstacleGround: null,
      obstacleLine: null,
      originalHitHeight: 0,
      surfaceDescription: "-",
    };
  }

  hitTestListener = (hitTestResult: any, newMapPoint: any) => {
    if (this.props.state === "OPENED") {
      loadArcGISJSAPIModules(["esri/Graphic", "esri/geometry/projection"]).then(
        (modules) => {
          let Graphic;
          let projection;

          [Graphic, projection] = modules;
          const jmv = this.state.jimuMapView;
          if (hitTestResult.results.length > 0) {
            this.setState({ disableMapNav: true });
            let retryGoTo = () => {
              jmv.view
                .goTo({
                  target: hitTestResult.results[0].mapPoint,
                  tilt: 0,
                })
                .then(
                  () => {
                    jmv.view
                      .hitTest(
                        { x: jmv.view.width / 2, y: jmv.view.height / 2 },
                        { exclude: [jmv.view.graphics] }
                      )
                      .then((hitTestResult: any) => {
                        this.setState({ disableMapNav: false });

                        let firstHit = null;
                        let lastHit = null;
                        if (hitTestResult.results.length > 0) {
                          // create point graphic for each hit on objects
                          let lowestPoint = hitTestResult.results[0];
                          hitTestResult.results.forEach((result) => {
                            if (result.mapPoint.z < lowestPoint.mapPoint.z) {
                              lowestPoint = result;
                            }
                          });

                          const surfaceDescription =
                            lowestPoint.graphic.attributes[
                              this.props.config.layerDescriptionField
                            ];
                          const obstacleSurface = new Graphic({
                            geometry: {
                              type: "point",
                              x: lowestPoint.mapPoint.x,
                              y: lowestPoint.mapPoint.y,
                              z: lowestPoint.mapPoint.z,
                              spatialReference: jmv.view.spatialReference,
                            },
                            symbol: this.firstObjectPointSymbol,
                          });
                          jmv.view.graphics.add(obstacleSurface);

                          const obstacleTop = new Graphic({
                            geometry: {
                              type: "point",
                              x: lowestPoint.mapPoint.x,
                              y: lowestPoint.mapPoint.y,
                              z: newMapPoint
                                ? newMapPoint.z.toFixed(4)
                                : lowestPoint.mapPoint.z.toFixed(4),
                              spatialReference: jmv.view.spatialReference,
                            },
                            symbol: this.objectPointSymbol,
                          });
                          jmv.view.graphics.add(obstacleTop);
                          firstHit = obstacleTop;

                          let graphic = lowestPoint.graphic;
                          // change the layer to be transparent
                          graphic.layer.opacity = 0.8;
                          // highlight the hit object
                          jmv.view
                            .whenLayerView(graphic.layer)
                            .then((layerView) => {
                              this.setState({
                                highlight: layerView.highlight(graphic),
                              });
                            });
                          this.setState({
                            obstacleSurface,
                            originalHitHeight: obstacleSurface.geometry.z,
                          });

                          this.setState({
                            obstacleTop,
                            obstacleSurface,
                            surfaceDescription,
                          });

                          const projObstacleTop = projection.project(
                            obstacleTop.geometry,
                            {
                              wkid: 4326,
                            }
                          );
                          this.obstacleXRef.current.value =
                            projObstacleTop.x.toFixed(8);
                          this.obstacleYRef.current.value =
                            projObstacleTop.y.toFixed(8);
                          this.obstacleZRef.current.value =
                            obstacleTop.geometry.z;
                        }

                        if (hitTestResult.ground.mapPoint) {
                          lastHit = hitTestResult.ground;

                          // create point graphic for the ground
                          const obstacleGround = new Graphic({
                            geometry: hitTestResult.ground.mapPoint,
                            symbol: this.groundPointSymbol,
                          });
                          jmv.view.graphics.add(obstacleGround);
                          lastHit = obstacleGround;

                          this.setState({
                            obstacleGround,
                          });
                        }

                        if (lastHit) {
                          // Draw a line to connect all hit objects and ground
                          let linePoints = [
                            [
                              firstHit.geometry.x,
                              firstHit.geometry.y,
                              firstHit.geometry.z,
                            ],
                            [
                              lastHit.geometry.x,
                              lastHit.geometry.y,
                              lastHit.geometry.z,
                            ],
                          ];

                          const obstacleLine = new Graphic({
                            geometry: {
                              type: "polyline",
                              paths: linePoints,
                              spatialReference: jmv.view.spatialReference,
                            },
                            symbol: this.lineSymbol,
                          });
                          jmv.view.graphics.add(obstacleLine);

                          this.setState({
                            obstacleLine,
                          });
                        }
                      });
                  },
                  () => {
                    retryGoTo();
                  }
                );
            };
            retryGoTo();
          }
        }
      );
    }
  };

  resetObstacle = () => {
    this.state.jimuMapView.view.graphics.removeAll();
    if (this.state.highlight) this.state.highlight.remove();
    this.setState({
      obstacleTop: null,
      obstacleGround: null,
      obstacleSurface: null,
      obstacleLine: null,
      originalHitHeight: 0,
      surfaceDescription: "-",
    });

    this.obstacleXRef.current.value = "0";
    this.obstacleYRef.current.value = "0";
    this.obstacleZRef.current.value = "0";
  };

  submitObstacle = () => {
    loadArcGISJSAPIModules(["esri/geometry/projection"]).then((modules) => {
      let projection;

      [projection] = modules;

      const newX = parseFloat(this.obstacleXRef.current.value).toFixed(8);
      const newY = parseFloat(this.obstacleYRef.current.value).toFixed(8);
      const newZ = parseFloat(this.obstacleZRef.current.value).toFixed(4);

      const projObstacleTop = projection.project(
        this.state.obstacleTop.geometry,
        { wkid: 4326 }
      );
      projObstacleTop.x = newX;
      projObstacleTop.y = newY;

      const newObstacleTopGeometry = projection.project(
        projObstacleTop,
        this.state.jimuMapView.view.spatialReference
      );
      newObstacleTopGeometry.z = newZ;
      const newScreenPoint = this.state.jimuMapView.view.toScreen(
        newObstacleTopGeometry
      );

      this.resetObstacle();
      this.state.jimuMapView.view
        .hitTest(newScreenPoint, { include: [this.state.surfaceLayer] })
        .then((hitTestResult) => {
          this.hitTestListener(hitTestResult, newObstacleTopGeometry);
        })
        .catch((error) => {
          console.error(error);
        });
    });
  };

  // obstacleCoordinateXChanged = (event) => {
  //   console.log(event);
  //   const newX = event.target.value;

  //   const newObstacleTopGeometry = this.state.obstacleTop.geometry;
  //   newObstacleTopGeometry.x = parseFloat(newX).toFixed(2);
  //   const newScreenPoint = this.state.jimuMapView.view.toScreen(
  //     newObstacleTopGeometry
  //   );

  //   this.resetObstacle();
  //   this.state.jimuMapView.view
  //     .hitTest(newScreenPoint, { include: [this.state.surfaceLayer] })
  //     .then(this.hitTestListener)
  //     .catch((error) => {
  //       console.error(error);
  //     });
  // };

  // obstacleCoordinateYChanged = (event) => {
  //   const newY = event.target.value;

  //   const newObstacleTopGeometry = this.state.obstacleTop.geometry;
  //   newObstacleTopGeometry.Y = parseFloat(newY).toFixed(2);
  //   const newScreenPoint = this.state.jimuMapView.view.toScreen(
  //     newObstacleTopGeometry
  //   );

  //   this.resetObstacle();
  //   this.state.jimuMapView.view
  //     .hitTest(newScreenPoint, { include: [this.state.surfaceLayer] })
  //     .then(this.hitTestListener)
  //     .catch((error) => {
  //       console.error(error);
  //     });
  // };

  // obstacleHeightChanged = (event) => {
  //   const newZ = event.target.value;

  //   loadArcGISJSAPIModules(["esri/Graphic"]).then((modules) => {
  //     let Graphic;

  //     [Graphic] = modules;

  //     const newObstacleTopGeometry = this.state.obstacleTop.geometry;
  //     newObstacleTopGeometry.z = parseFloat(newZ).toFixed(2);
  //     const newObstacleTop = new Graphic({
  //       geometry: newObstacleTopGeometry,
  //       symbol: this.objectPointSymbol,
  //     });
  //     this.state.jimuMapView.view.graphics.remove(this.state.obstacleTop);
  //     this.state.jimuMapView.view.graphics.add(newObstacleTop);

  //     this.setState({ obstacleTop: newObstacleTop });

  //     this.obstacleXRef.current.value = newObstacleTop.geometry.x;
  //     this.obstacleYRef.current.value = newObstacleTop.geometry.y;
  //     this.obstacleZRef.current.value = newObstacleTop.geometry.z;

  //     let linePoints = [
  //       [
  //         newObstacleTopGeometry.x,
  //         newObstacleTopGeometry.y,
  //         newObstacleTopGeometry.z,
  //       ],
  //       [
  //         this.state.obstacleGround.geometry.x,
  //         this.state.obstacleGround.geometry.y,
  //         this.state.obstacleGround.geometry.z,
  //       ],
  //     ];

  //     const newObstacleLine = new Graphic({
  //       geometry: {
  //         type: "polyline",
  //         paths: linePoints,
  //         spatialReference: this.state.jimuMapView.view.spatialReference,
  //       },
  //       symbol: this.lineSymbol,
  //     });
  //     this.state.jimuMapView.view.graphics.remove(this.state.obstacleLine);
  //     this.state.jimuMapView.view.graphics.add(newObstacleLine);
  //     this.setState({ obstacleLine: newObstacleLine });
  //   });
  // };

  activeViewChangeHandler = (jmv: JimuMapView) => {
    if (this.state.jimuMapView) {
      if (this.state.currentWidget) {
        this.state.currentWidget.destroy();
      }
    }

    if (jmv) {
      this.setState({
        jimuMapView: jmv,
      });

      if (this.myRef.current) {
        loadArcGISJSAPIModules(["esri/Graphic"]).then((modules) => {
          let Graphic;

          [Graphic] = modules;

          if (!this.props.config.hasOwnProperty("layerName")) {
            this.setState({
              errorMessage: "You must configure this widget with a layer name",
            });
            return;
          }

          if (!this.props.config.hasOwnProperty("layerDescriptionField")) {
            this.setState({
              errorMessage:
                "You must configure this widget with a layer description field",
            });
            return;
          }

          const surfaceLayers = jmv.view.layerViews.filter((layerView) => {
            return layerView.layer.title === this.props.config.layerName;
          });
          if (surfaceLayers.length > 0) {
            this.setState({ surfaceLayer: surfaceLayers[0] });
          } else {
            this.setState({
              errorMessage: `Could not find layer name "${this.props.config.layerName}". You need to reconfigure this widget.`,
            });
            return;
          }

          jmv.view.on("click", (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("key-down", (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("mouse-wheel", (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("double-click", (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("double-click", ["Control"], (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("drag", (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("drag", ["Shift"], (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("drag", ["Shift", "Control"], (event) => {
            if (this.state.disableMapNav) event.stopPropagation();
          });

          jmv.view.on("immediate-click", (event) => {
            if (this.state.disableMapNav) return;

            this.resetObstacle();
            // get the returned hitTestResult
            // and draw points on all return mappoints and connect to a line
            // (using promise chaining for cleaner code and error handling)
            jmv.view
              .hitTest(event, { include: [this.state.surfaceLayer] })
              .then((hitTestResult) => {
                this.hitTestListener(hitTestResult, null);
              })
              .catch((error) => {
                console.error(error);
              });
          });
        });
      } else {
        console.error("could not find this.myRef.current");
      }
    }
  };

  render() {
    let mvc = <p>{defaultMessages.selectAMapWarning}</p>;
    if (
      this.props.hasOwnProperty("useMapWidgetIds") &&
      this.props.useMapWidgetIds &&
      this.props.useMapWidgetIds.length === 1
    ) {
      mvc = (
        <JimuMapViewComponent
          useMapWidgetIds={this.props.useMapWidgetIds}
          onActiveViewChange={this.activeViewChangeHandler}
        />
      );
    }

    let content;
    if (this.state.errorMessage) {
      content = <p>{this.state.errorMessage}</p>;
    } else {
      let deltaZ = "-";
      let deltaZColor = "black";
      if (this.state.originalHitHeight && this.state.obstacleTop) {
        deltaZ = (
          this.state.obstacleTop.geometry.z - this.state.originalHitHeight
        ).toFixed(2);

        if (parseFloat(deltaZ) > 0.01) deltaZColor = "red";
        else if (parseFloat(deltaZ) < -0.01) deltaZColor = "green";
      }
      content = (
        <div>
          <p>
            <b>{defaultMessages.placeObstacleLabel}</b>
          </p>
          <table style={{ width: "100%" }}>
            <tr>
              <td>
                <b>{defaultMessages.obstacleCoordinatesLabelY}</b>
              </td>
              <td>
                <input
                  type="number"
                  // onSubmit={this.obstacleCoordinateYChanged}
                  step="0.01"
                  // value={
                  //   this.state.obstacleTop
                  //     ? this.state.obstacleTop.geometry.y
                  //     : 0
                  // }
                  ref={this.obstacleYRef}
                />
              </td>
            </tr>
            <tr>
              <td>
                <b>{defaultMessages.obstacleCoordinatesLabelX}</b>
              </td>
              <td>
                <input
                  type="number"
                  // onSubmit={this.obstacleCoordinateXChanged}
                  step="0.01"
                  // value={
                  //   this.state.obstacleTop
                  //     ? this.state.obstacleTop.geometry.x
                  //     : 0
                  // }
                  ref={this.obstacleXRef}
                />
              </td>
            </tr>
            <tr>
              <td>
                <b>{defaultMessages.obstacleHeightLabel}</b>
              </td>
              <td>
                <input
                  type="number"
                  // onSubmit={this.obstacleHeightChanged}
                  step="0.01"
                  // value={
                  //   this.state.obstacleTop
                  //     ? this.state.obstacleTop.geometry.z
                  //     : 0
                  // }
                  ref={this.obstacleZRef}
                />
                {" m"}
              </td>
            </tr>
            <tr>
              <td>
                <b>{defaultMessages.surfaceDescriptionLabel}</b>
              </td>
              <td>{this.state.surfaceDescription}</td>
            </tr>
            <tr>
              <td>
                <b>{defaultMessages.groundElevationLabel}</b>
              </td>
              <td>
                {this.state.obstacleGround
                  ? this.state.obstacleGround.geometry.z.toFixed(2)
                  : 0}
                {" m"}
              </td>
            </tr>
            <tr>
              <td>
                <b>{defaultMessages.oisElevationLabel}</b>
              </td>
              <td>
                {this.state.obstacleSurface
                  ? this.state.obstacleSurface.geometry.z.toFixed(2)
                  : 0}
                {" m"}
              </td>
            </tr>
            <tr>
              <td>
                <b>{defaultMessages.deltaZLabel}</b>
              </td>
              <td style={{ color: deltaZColor }}>{deltaZ}</td>
            </tr>
          </table>
          <br></br>
          <Button
            type="primary"
            onClick={this.submitObstacle}
            ref={this.submitButtonRef}
            style={{ marginRight: "10px" }}
          >
            {defaultMessages.submitButtonLabel}
          </Button>
          <Button
            type="secondary"
            onClick={this.resetObstacle}
            ref={this.resetButtonRef}
          >
            {defaultMessages.resetButtonLabel}
          </Button>
        </div>
      );
    }

    return (
      <div
        className="aviation-obstacle-identifier jimu-widget m-2"
        style={getStyle()}
      >
        <div ref={this.myRef} className="esri-widget">
          {content}
        </div>
        {mvc}
      </div>
    );
  }
}
