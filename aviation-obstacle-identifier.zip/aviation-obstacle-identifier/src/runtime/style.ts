export function getStyle() {
  return {};
}
