export default {
  selectAMapWarning: "Please select a map.",
  placeObstacleLabel: "Click on the map to place an obstacle:",
  groundElevationLabel: "Ground Elevation:",
  oisElevationLabel: "OIS Elevation:",
  obstacleHeightLabel: "Height:",
  deltaZLabel: "Penetration:",
  resetButtonLabel: "Reset",
  submitButtonLabel: "Submit",
  surfaceDescriptionLabel: "Surface Description:",
  obstacleCoordinatesLabelX: "Longitude:",
  obstacleCoordinatesLabelY: "Latitude:",
};
