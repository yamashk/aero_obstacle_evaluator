import { ImmutableObject } from "seamless-immutable";

export interface Config {
  layerName: string;
  layerDescriptionField: string;
}

export type IMConfig = ImmutableObject<Config>;
